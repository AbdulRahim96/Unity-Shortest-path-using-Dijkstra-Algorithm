using System.Collections.Generic;
using UnityEngine;

public class Node : MonoBehaviour
{
    public List<Node> neighbors = new List<Node>();
    // You can add additional properties here as needed, like neighbors, distances, etc.
}
